document.addEventListener("DOMContentLoaded", function () {
    const chatInput = document.getElementById("user-query");
    const askButton = document.getElementById("ask-btn");
    const userQueryBox = document.getElementById("user-query-box");
    const responseBox = document.getElementById("response-box");
    const greeting = document.getElementById("greeting");
    const researchOptions = document.querySelector(".research-options");
    const chatContainer = document.querySelector(".chat-container");
    const body = document.body;

    function sendQuery() {
        const userQuery = chatInput.value.trim();
        if (!userQuery) return;

        // Hide greeting and research buttons
        greeting.style.display = "none";
        researchOptions.style.display = "none";

        // Make UI minimalistic
        body.style.background = "#121417"; // Darker background
        chatContainer.style.border = "none"; 
        chatContainer.style.background = "transparent";

        // Show user input and output boxes
        userQueryBox.classList.remove("hidden");
        responseBox.classList.remove("hidden");

        // Display user input in separate box
        userQueryBox.innerHTML = `<strong>You:</strong> ${userQuery}`;

        // Show loading message in response box
        responseBox.innerHTML = `<strong>Socretes:</strong> Thinking... ⏳`;

        chatInput.value = ""; // Clear input field

        // Fetch response from backend (replace with actual API endpoint)
        fetch("/ask_gemini", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: userQuery })
        })
        .then(response => response.json())
        .then(data => {
            responseBox.innerHTML = `<strong>Socretes:</strong> ${data.response}`;
        })
        .catch(error => {
            responseBox.innerHTML = `<strong>Socretes:</strong> Error fetching response.`;
        });
    }

    askButton.addEventListener("click", sendQuery);
    chatInput.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            sendQuery();
        }
    });

    // Attach event listeners to research buttons dynamically
    document.querySelectorAll(".research-btn").forEach(button => {
        button.addEventListener("click", function () {
            chatInput.value = this.getAttribute("data-query");
            chatInput.focus();
        });
    });

    // Hide the user input and output box initially
    userQueryBox.classList.add("hidden");
    responseBox.classList.add("hidden");
});

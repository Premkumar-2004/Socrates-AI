import requests

# Replace with your actual Google Gemini API key
api_key = "AIzaSyBnDf1W6kbFd7wldJY2oeSmM0dv3HNkICc"

headers = {
    "Content-Type": "application/json"
}

payload = {
    "contents": [
        {
            "parts": [
                {"text": "Hello"}
            ]
        }
    ]
}

# ✅ Corrected API URL with the correct model name
api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"

# Send request to Gemini
response = requests.post(api_url, headers=headers, json=payload)

# Print response
print(response.status_code, response.json())
